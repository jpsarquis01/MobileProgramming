pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "GladeTowns"
include(":app")
// Planned module split (Phase 2+, see docs/ARCHITECTURE.md §1.2):
// include(":core:domain", ":core:data", ":core:engine", ":core:ui")
