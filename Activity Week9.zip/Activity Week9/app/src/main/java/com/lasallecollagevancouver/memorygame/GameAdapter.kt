// GameAdapter.kt
package com.lasallecollagevancouver.memorygame

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.setMargins
import androidx.recyclerview.widget.RecyclerView

class GameAdapter () : RecyclerView.Adapter<TileViewHolder> ()
{
    private var firstFlippedIndex: Int = -1
    private var secondFlippedIndex: Int = -1
    private var isBoardLocked: Boolean = false

    override fun getItemCount(): Int = AppData.tileArr.count()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        index: Int
    ): TileViewHolder {
        val root = LayoutInflater.from(parent.context).inflate(R.layout.tile_layout,
            parent, false)
                as FrameLayout
        return TileViewHolder (root)
    }

    override fun onBindViewHolder(viewHolder: TileViewHolder, index: Int) {
        val tile = AppData.tileArr[index]

        val params = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT)

        tile.layoutParams = params
        params.setMargins(5)
        tile.textSize = 36f
        tile.gravity = Gravity.CENTER

        // Remove from any previous parent before adding
        (tile.parent as? ViewGroup)?.removeView(tile)
        viewHolder.root.removeAllViews()
        viewHolder.root.addView(tile)

        tile.updateTile()

        viewHolder.root.setOnClickListener {
            val currentIndex = viewHolder.bindingAdapterPosition
            if (currentIndex == RecyclerView.NO_ID.toInt()) return@setOnClickListener

            val currentTile = AppData.tileArr[currentIndex]

            if (isBoardLocked) return@setOnClickListener
            if (currentTile.status == Status.MATCHED) return@setOnClickListener
            if (currentTile.status == Status.FLIPPED) return@setOnClickListener

            currentTile.status = Status.FLIPPED
            currentTile.updateTile()

            if (firstFlippedIndex == -1) {
                firstFlippedIndex = currentIndex
            } else {
                secondFlippedIndex = currentIndex
                isBoardLocked = true

                val firstTile = AppData.tileArr[firstFlippedIndex]
                val secondTile = AppData.tileArr[secondFlippedIndex]

                if (firstTile.num == secondTile.num) {
                    firstTile.status = Status.MATCHED
                    secondTile.status = Status.MATCHED
                    firstTile.updateTile()
                    secondTile.updateTile()
                    resetSelection()
                    isBoardLocked = false
                } else {
                    Handler(Looper.getMainLooper()).postDelayed({
                        firstTile.status = Status.HIDDEN
                        secondTile.status = Status.HIDDEN
                        firstTile.updateTile()
                        secondTile.updateTile()
                        resetSelection()
                        isBoardLocked = false
                    }, 900L)
                }
            }
        }
    }

    private fun resetSelection() {
        firstFlippedIndex = -1
        secondFlippedIndex = -1
    }

    fun reset() {
        resetSelection()
        isBoardLocked = false
    }
}
